########################################
#          IMPORTANT NOTICE            #
########################################
# READ THIS FILE FIRST BEFORE USING,   #
# MODIFYING, OR EDITING THIS POSTER.   #
########################################
# This file can be used, reproduced, and modified with proper attribution.
# The "Seoul" logo and the "KCDA" logo may not be removed or edited.
# The exported poster can only be used for small sizes.
# To use high quality posters please export with the provided project
# with Adobe Illustrator.
########################################
# BY USING THIS POSTER YOU AGREE THE   #
# TERMS ABOVE. IF YOU NOT AGREE,       #
# YOU ARE FORBIDDEN TO USE THIS        #
# POSTER.                              #
########################################
